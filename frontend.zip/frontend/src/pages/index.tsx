import Home from './Home';
import Login from './Login';
import Register from './Register';
import Details from './Details';
import AddOrEditBlog from './AddOrEditBlog';
import Profile from './Profile';

export { Home, Login, Register, Details, AddOrEditBlog, Profile };
