location of blog images
